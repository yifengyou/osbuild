"""
Concrete representation of manifest descriptions
"""
