#
# Define some useful typing abbreviations
#

#: Represents a file system path. See also `os.fspath`.
PathLike = str
