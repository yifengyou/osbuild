# The `unittest` module requires `__init__.py` to discover a directory.
